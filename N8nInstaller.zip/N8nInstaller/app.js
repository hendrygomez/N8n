const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

class N8nSetup {
    constructor() {
        this.n8nProcess = null;
        this.isN8nInstalled = false;
        this.installationInProgress = false;
    }

    async checkN8nInstallation() {
        return new Promise((resolve) => {
            exec('npm list -g n8n --depth=0', (error, stdout, stderr) => {
                if (error) {
                    console.log('n8n not found globally, checking local installation...');
                    exec('npm list n8n --depth=0', (localError, localStdout, localStderr) => {
                        resolve(!localError);
                    });
                } else {
                    resolve(true);
                }
            });
        });
    }

    async installN8n() {
        if (this.installationInProgress) {
            return false;
        }

        this.installationInProgress = true;
        console.log('Installing n8n...');

        return new Promise((resolve, reject) => {
            // Install n8n locally to avoid permission issues
            const installProcess = spawn('npm', ['install', 'n8n@latest'], {
                stdio: 'inherit',
                shell: true
            });

            installProcess.on('close', (code) => {
                this.installationInProgress = false;
                if (code === 0) {
                    console.log('n8n installed successfully!');
                    this.isN8nInstalled = true;
                    resolve(true);
                } else {
                    console.error('Failed to install n8n');
                    reject(new Error(`Installation failed with code ${code}`));
                }
            });

            installProcess.on('error', (error) => {
                this.installationInProgress = false;
                console.error('Installation error:', error);
                reject(error);
            });
        });
    }

    setupN8nConfig() {
        const config = {
            N8N_HOST: '0.0.0.0',
            N8N_PORT: '5000',
            N8N_PROTOCOL: 'http',
            DB_TYPE: 'sqlite',
            DB_SQLITE_DATABASE: './database/n8n_data.sqlite',
            DB_SQLITE_ENABLE_WAL: 'true',
            N8N_BASIC_AUTH_ACTIVE: 'false',
            N8N_METRICS: 'true',
            N8N_WEBHOOK_URL: 'http://0.0.0.0:5000',
            N8N_SECURE_COOKIE: 'false',
            N8N_DISABLE_PRODUCTION_MAIN_PROCESS: 'true',
            N8N_SKIP_WEBHOOK_DEREGISTRATION_SHUTDOWN: 'true',
            N8N_WEBHOOK_TEST_ENABLED: 'false',
            N8N_ENFORCE_WEBHOOK_HTTPS: 'false',
            NODE_ENV: 'development',
            N8N_LOG_LEVEL: 'info',
            N8N_LOG_OUTPUT: 'console',
            EXECUTIONS_DATA_SAVE_ON_ERROR: 'all',
            EXECUTIONS_DATA_SAVE_ON_SUCCESS: 'all',
            EXECUTIONS_DATA_SAVE_MANUAL_EXECUTIONS: 'true'
        };

        // Set environment variables
        Object.keys(config).forEach(key => {
            process.env[key] = config[key];
        });

        console.log('n8n configuration set up successfully');
        return config;
    }

    async importWorkflows() {
        const workflowsDir = path.join(__dirname, 'workflows');
        
        if (!fs.existsSync(workflowsDir)) {
            console.log('No workflows directory found, skipping workflow import');
            return;
        }

        const workflowFiles = fs.readdirSync(workflowsDir).filter(file => file.endsWith('.json'));
        
        for (const file of workflowFiles) {
            try {
                const workflowPath = path.join(workflowsDir, file);
                const workflowData = JSON.parse(fs.readFileSync(workflowPath, 'utf8'));
                console.log(`Workflow template available: ${workflowData.name || file}`);
            } catch (error) {
                console.error(`Error reading workflow ${file}:`, error.message);
            }
        }
    }

    async startN8n() {
        return new Promise((resolve, reject) => {
            console.log('Starting n8n...');
            
            // Use npx to run n8n from local installation
            this.n8nProcess = spawn('npx', ['n8n', 'start'], {
                stdio: 'inherit',
                shell: true,
                env: process.env
            });

            this.n8nProcess.on('error', (error) => {
                console.error('Failed to start n8n:', error);
                reject(error);
            });

            // Give n8n some time to start
            setTimeout(() => {
                console.log('n8n should be starting up...');
                resolve(true);
            }, 3000);
        });
    }

    async setupComplete() {
        console.log('\n=== n8n Setup Complete ===');
        console.log('n8n is running on: http://localhost:5000');
        console.log('Access the web interface to create workflows');
        console.log('Press Ctrl+C to stop n8n');
        console.log('========================\n');
        
        // Start integrated keep alive functionality
        this.startKeepAlive();
    }

    startKeepAlive() {
        console.log('🔄 Starting integrated keep-alive system...');
        
        // Ping external services every 5 minutes
        setInterval(() => {
            this.pingExternal();
        }, 5 * 60 * 1000);

        // Simulate activity every 2 minutes
        setInterval(() => {
            this.simulateActivity();
        }, 2 * 60 * 1000);

        // Self health check every 30 seconds
        setInterval(() => {
            this.selfHealthCheck();
        }, 30 * 1000);

        // Start initial activity
        setTimeout(() => {
            this.pingExternal();
            this.simulateActivity();
        }, 5000);

        console.log('✅ Keep-alive system activated');
    }

    pingExternal() {
        const https = require('https');
        const urls = [
            'https://httpbin.org/get',
            'https://api.github.com',
            'https://jsonplaceholder.typicode.com/posts/1'
        ];

        urls.forEach(url => {
            https.get(url, (res) => {
                console.log(`📡 Pinged ${url} - Status: ${res.statusCode}`);
            }).on('error', () => {
                // Silent error handling
            });
        });
    }

    simulateActivity() {
        // Generate CPU activity
        const start = Date.now();
        let counter = 0;
        while (Date.now() - start < 50) {
            counter += Math.random();
        }

        // Memory activity
        const tempArray = new Array(500).fill(0).map(() => Math.random());
        tempArray.sort();

        // File system activity
        const fs = require('fs');
        fs.writeFileSync('.activity-log', new Date().toISOString());

        console.log(`🎯 Activity simulated - ${new Date().toISOString()}`);
    }

    selfHealthCheck() {
        const options = {
            hostname: 'localhost',
            port: 5000,
            path: '/healthz',
            method: 'GET',
            timeout: 3000
        };

        const req = http.request(options, (res) => {
            console.log(`💚 Self health check OK - ${res.statusCode}`);
        });

        req.on('error', () => {
            console.log('❤️‍🩹 Self health check failed');
        });

        req.setTimeout(3000, () => {
            req.destroy();
        });

        req.end();
    }

    handleShutdown() {
        console.log('\nShutting down n8n...');
        if (this.n8nProcess) {
            this.n8nProcess.kill('SIGTERM');
        }
        process.exit(0);
    }
}

// Main execution
async function main() {
    const n8nSetup = new N8nSetup();

    // Handle graceful shutdown
    process.on('SIGINT', () => n8nSetup.handleShutdown());
    process.on('SIGTERM', () => n8nSetup.handleShutdown());

    try {
        // Check if n8n is already installed
        const isInstalled = await n8nSetup.checkN8nInstallation();
        
        if (!isInstalled) {
            console.log('n8n not found. Installing...');
            await n8nSetup.installN8n();
        } else {
            console.log('n8n is already installed');
            n8nSetup.isN8nInstalled = true;
        }

        // Set up configuration
        n8nSetup.setupN8nConfig();

        // Import example workflows
        await n8nSetup.importWorkflows();

        // Start n8n
        await n8nSetup.startN8n();
        
        // Setup complete message
        await n8nSetup.setupComplete();

    } catch (error) {
        console.error('Setup failed:', error);
        process.exit(1);
    }
}

// Start the application
if (require.main === module) {
    main();
}

module.exports = N8nSetup;
