const http = require('http');
const https = require('https');
const { exec } = require('child_process');

class KeepAliveServer {
    constructor() {
        this.port = 3000;
        this.n8nPort = 5000;
        this.pingInterval = 5 * 60 * 1000; // 5 minutes
        this.healthCheckInterval = 30 * 1000; // 30 seconds
        this.activityInterval = 2 * 60 * 1000; // 2 minutes
        this.server = null;
        this.intervals = [];
    }

    // Create HTTP server that responds to requests
    createServer() {
        this.server = http.createServer((req, res) => {
            const url = req.url;
            const method = req.method;

            // Health check endpoint
            if (url === '/health' || url === '/ping') {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    status: 'alive',
                    timestamp: new Date().toISOString(),
                    uptime: process.uptime(),
                    n8n_running: true
                }));
                return;
            }

            // Activity simulator endpoint
            if (url === '/activity') {
                this.simulateActivity();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    message: 'Activity simulated',
                    timestamp: new Date().toISOString()
                }));
                return;
            }

            // Status endpoint
            if (url === '/status') {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    keepalive_server: 'running',
                    port: this.port,
                    n8n_port: this.n8nPort,
                    intervals_active: this.intervals.length,
                    timestamp: new Date().toISOString()
                }));
                return;
            }

            // Default response
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
                <html>
                    <head><title>Keep Alive Server</title></head>
                    <body>
                        <h1>🔄 Keep Alive Server Active</h1>
                        <p>Server is running and keeping the project alive</p>
                        <p>Current time: ${new Date().toISOString()}</p>
                        <ul>
                            <li><a href="/health">Health Check</a></li>
                            <li><a href="/status">Server Status</a></li>
                            <li><a href="/activity">Trigger Activity</a></li>
                        </ul>
                    </body>
                </html>
            `);
        });

        this.server.listen(this.port, '0.0.0.0', () => {
            console.log(`🔄 Keep Alive server running on port ${this.port}`);
            console.log(`Server accessible at http://localhost:${this.port}`);
        });
    }

    // Ping external services to maintain activity
    pingExternal() {
        const urls = [
            'https://httpbin.org/get',
            'https://api.github.com',
            'https://jsonplaceholder.typicode.com/posts/1'
        ];

        urls.forEach(url => {
            const protocol = url.startsWith('https') ? https : http;
            protocol.get(url, (res) => {
                console.log(`📡 Pinged ${url} - Status: ${res.statusCode}`);
            }).on('error', (err) => {
                console.log(`❌ Ping failed for ${url}: ${err.message}`);
            });
        });
    }

    // Check n8n health
    checkN8nHealth() {
        const options = {
            hostname: 'localhost',
            port: this.n8nPort,
            path: '/healthz',
            method: 'GET',
            timeout: 5000
        };

        const req = http.request(options, (res) => {
            console.log(`💚 n8n health check - Status: ${res.statusCode}`);
        });

        req.on('error', (err) => {
            console.log(`❤️‍🩹 n8n health check failed: ${err.message}`);
        });

        req.on('timeout', () => {
            console.log('⏱️ n8n health check timeout');
            req.destroy();
        });

        req.end();
    }

    // Simulate activity to prevent idle shutdown
    simulateActivity() {
        // Generate some CPU activity
        const start = Date.now();
        let counter = 0;
        while (Date.now() - start < 100) {
            counter += Math.random();
        }

        // Create memory activity
        const tempArray = new Array(1000).fill(0).map(() => Math.random());
        tempArray.sort();

        // File system activity
        const fs = require('fs');
        const timestamp = Date.now();
        fs.writeFileSync('.keepalive-activity', timestamp.toString());

        console.log(`🎯 Activity simulated - Counter: ${counter.toFixed(2)}, Array: ${tempArray.length}`);
    }

    // Self ping to maintain connection
    selfPing() {
        const options = {
            hostname: 'localhost',
            port: this.port,
            path: '/health',
            method: 'GET'
        };

        const req = http.request(options, (res) => {
            console.log(`🔄 Self ping successful - ${new Date().toISOString()}`);
        });

        req.on('error', (err) => {
            console.log(`🔄 Self ping error: ${err.message}`);
        });

        req.end();
    }

    // Start all keep-alive mechanisms
    start() {
        console.log('🚀 Starting Keep Alive Server...');
        
        // Create HTTP server
        this.createServer();

        // Set up intervals
        this.intervals.push(
            setInterval(() => this.pingExternal(), this.pingInterval)
        );

        this.intervals.push(
            setInterval(() => this.checkN8nHealth(), this.healthCheckInterval)
        );

        this.intervals.push(
            setInterval(() => this.simulateActivity(), this.activityInterval)
        );

        this.intervals.push(
            setInterval(() => this.selfPing(), this.pingInterval)
        );

        // Initial activity
        setTimeout(() => {
            this.pingExternal();
            this.checkN8nHealth();
            this.simulateActivity();
        }, 5000);

        console.log('✅ Keep Alive mechanisms activated');
        console.log(`📊 Ping interval: ${this.pingInterval / 1000}s`);
        console.log(`🏥 Health check interval: ${this.healthCheckInterval / 1000}s`);
        console.log(`🎯 Activity interval: ${this.activityInterval / 1000}s`);
    }

    // Stop all mechanisms
    stop() {
        console.log('🛑 Stopping Keep Alive Server...');
        
        this.intervals.forEach(interval => clearInterval(interval));
        this.intervals = [];

        if (this.server) {
            this.server.close(() => {
                console.log('🔴 Keep Alive server stopped');
            });
        }
    }

    // Handle graceful shutdown
    handleShutdown() {
        console.log('\n📴 Shutting down Keep Alive server...');
        this.stop();
        process.exit(0);
    }
}

// Main execution
const keepAlive = new KeepAliveServer();

// Handle graceful shutdown
process.on('SIGINT', () => keepAlive.handleShutdown());
process.on('SIGTERM', () => keepAlive.handleShutdown());

// Start the keep alive server
keepAlive.start();

module.exports = KeepAliveServer;