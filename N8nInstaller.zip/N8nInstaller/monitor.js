const http = require('http');
const { exec } = require('child_process');
const fs = require('fs');

class ProjectMonitor {
    constructor() {
        this.monitorPort = 8080;
        this.n8nPort = 5000;
        this.keepAlivePort = 3000;
        this.checkInterval = 30000; // 30 seconds
        this.restartAttempts = 0;
        this.maxRestartAttempts = 5;
        this.isMonitoring = false;
    }

    // Check if n8n is running
    checkN8nStatus() {
        return new Promise((resolve) => {
            const req = http.get(`http://localhost:${this.n8nPort}/healthz`, (res) => {
                resolve(res.statusCode === 200);
            });
            
            req.on('error', () => resolve(false));
            req.setTimeout(5000, () => {
                req.destroy();
                resolve(false);
            });
        });
    }

    // Check if keep alive server is running
    checkKeepAliveStatus() {
        return new Promise((resolve) => {
            const req = http.get(`http://localhost:${this.keepAlivePort}/health`, (res) => {
                resolve(res.statusCode === 200);
            });
            
            req.on('error', () => resolve(false));
            req.setTimeout(5000, () => {
                req.destroy();
                resolve(false);
            });
        });
    }

    // Restart n8n if it's down
    restartN8n() {
        if (this.restartAttempts >= this.maxRestartAttempts) {
            console.log(`❌ Max restart attempts (${this.maxRestartAttempts}) reached`);
            return;
        }

        this.restartAttempts++;
        console.log(`🔄 Attempting to restart n8n (attempt ${this.restartAttempts}/${this.maxRestartAttempts})`);

        exec('node app.js', (error, stdout, stderr) => {
            if (error) {
                console.log(`❌ Restart failed: ${error.message}`);
            } else {
                console.log(`✅ n8n restart initiated`);
                this.restartAttempts = 0; // Reset on successful start
            }
        });
    }

    // Perform health checks
    async performHealthCheck() {
        const timestamp = new Date().toISOString();
        console.log(`🔍 Health check at ${timestamp}`);

        const n8nStatus = await this.checkN8nStatus();
        const keepAliveStatus = await this.checkKeepAliveStatus();

        console.log(`n8n: ${n8nStatus ? '✅' : '❌'} | Keep Alive: ${keepAliveStatus ? '✅' : '❌'}`);

        // Log status to file
        const logEntry = {
            timestamp,
            n8n_running: n8nStatus,
            keepalive_running: keepAliveStatus,
            restart_attempts: this.restartAttempts
        };

        fs.appendFileSync('monitor.log', JSON.stringify(logEntry) + '\n');

        // Restart if n8n is down
        if (!n8nStatus) {
            console.log('⚠️ n8n is down, attempting restart...');
            this.restartN8n();
        }

        return { n8nStatus, keepAliveStatus };
    }

    // Create monitor web interface
    createMonitorServer() {
        const server = http.createServer(async (req, res) => {
            if (req.url === '/status') {
                const health = await this.performHealthCheck();
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    monitor_active: this.isMonitoring,
                    n8n_running: health.n8nStatus,
                    keepalive_running: health.keepAliveStatus,
                    restart_attempts: this.restartAttempts,
                    timestamp: new Date().toISOString()
                }));
                return;
            }

            if (req.url === '/logs') {
                try {
                    const logs = fs.readFileSync('monitor.log', 'utf8').split('\n').filter(line => line);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify(logs.map(log => JSON.parse(log))));
                } catch (error) {
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify([]));
                }
                return;
            }

            // Default monitor dashboard
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end(`
                <html>
                    <head>
                        <title>Project Monitor</title>
                        <meta http-equiv="refresh" content="30">
                        <style>
                            body { font-family: Arial, sans-serif; margin: 20px; }
                            .status { padding: 10px; margin: 10px 0; border-radius: 5px; }
                            .running { background-color: #d4edda; color: #155724; }
                            .stopped { background-color: #f8d7da; color: #721c24; }
                        </style>
                    </head>
                    <body>
                        <h1>🔍 Project Monitor Dashboard</h1>
                        <p>Monitor refreshes every 30 seconds</p>
                        <div id="status">Loading...</div>
                        <script>
                            async function updateStatus() {
                                try {
                                    const response = await fetch('/status');
                                    const data = await response.json();
                                    document.getElementById('status').innerHTML = \`
                                        <div class="\${data.n8n_running ? 'status running' : 'status stopped'}">
                                            n8n Server: \${data.n8n_running ? 'Running' : 'Stopped'}
                                        </div>
                                        <div class="\${data.keepalive_running ? 'status running' : 'status stopped'}">
                                            Keep Alive: \${data.keepalive_running ? 'Running' : 'Stopped'}
                                        </div>
                                        <div class="status">
                                            Monitor Active: \${data.monitor_active ? 'Yes' : 'No'}
                                        </div>
                                        <div class="status">
                                            Restart Attempts: \${data.restart_attempts}
                                        </div>
                                        <div class="status">
                                            Last Check: \${data.timestamp}
                                        </div>
                                    \`;
                                } catch (error) {
                                    document.getElementById('status').innerHTML = '<div class="status stopped">Monitor Error</div>';
                                }
                            }
                            updateStatus();
                            setInterval(updateStatus, 10000);
                        </script>
                    </body>
                </html>
            `);
        });

        server.listen(this.monitorPort, '0.0.0.0', () => {
            console.log(`🔍 Monitor dashboard running on port ${this.monitorPort}`);
        });
    }

    // Start monitoring
    start() {
        console.log('🚀 Starting Project Monitor...');
        this.isMonitoring = true;

        // Create monitor web interface
        this.createMonitorServer();

        // Start periodic health checks
        setInterval(() => {
            this.performHealthCheck();
        }, this.checkInterval);

        // Initial health check
        setTimeout(() => {
            this.performHealthCheck();
        }, 5000);

        console.log(`✅ Monitor active - Check interval: ${this.checkInterval/1000}s`);
    }

    // Stop monitoring
    stop() {
        this.isMonitoring = false;
        console.log('🛑 Project Monitor stopped');
    }
}

// Start monitor if run directly
if (require.main === module) {
    const monitor = new ProjectMonitor();
    monitor.start();

    // Handle graceful shutdown
    process.on('SIGINT', () => {
        monitor.stop();
        process.exit(0);
    });
}

module.exports = ProjectMonitor;