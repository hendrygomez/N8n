const fs = require('fs');
const path = require('path');

class SetupValidator {
    constructor() {
        this.requiredFiles = [
            'app.js',
            'n8n-config.json',
            'startup.sh',
            'workflows/example-webhook.json',
            'workflows/example-scheduler.json',
            'public/index.html'
        ];
    }

    validateSetup() {
        console.log('=== n8n Setup Validation ===');
        
        let allValid = true;
        
        for (const file of this.requiredFiles) {
            const filePath = path.join(__dirname, file);
            const exists = fs.existsSync(filePath);
            
            console.log(`${exists ? '✓' : '✗'} ${file}`);
            
            if (!exists) {
                allValid = false;
            }
        }

        if (allValid) {
            console.log('\n✓ All required files are present');
            console.log('✓ Setup validation completed successfully');
            this.displayUsageInstructions();
        } else {
            console.log('\n✗ Some required files are missing');
            console.log('Please ensure all files are created properly');
        }

        return allValid;
    }

    displayUsageInstructions() {
        console.log('\n=== Usage Instructions ===');
        console.log('1. Run: chmod +x startup.sh');
        console.log('2. Run: ./startup.sh');
        console.log('   OR');
        console.log('2. Run: node app.js');
        console.log('\nThe n8n interface will be available at: http://localhost:5000');
        console.log('============================\n');
    }

    createDirectories() {
        const directories = [
            'workflows',
            'public'
        ];

        directories.forEach(dir => {
            const dirPath = path.join(__dirname, dir);
            if (!fs.existsSync(dirPath)) {
                fs.mkdirSync(dirPath, { recursive: true });
                console.log(`Created directory: ${dir}`);
            }
        });
    }

    setupPermissions() {
        try {
            const startupScript = path.join(__dirname, 'startup.sh');
            if (fs.existsSync(startupScript)) {
                fs.chmodSync(startupScript, '755');
                console.log('Set executable permissions for startup.sh');
            }
        } catch (error) {
            console.log('Note: Could not set permissions automatically. Run: chmod +x startup.sh');
        }
    }

    init() {
        console.log('Initializing n8n setup...');
        this.createDirectories();
        this.setupPermissions();
        return this.validateSetup();
    }
}

// Run setup validation if called directly
if (require.main === module) {
    const validator = new SetupValidator();
    const isValid = validator.init();
    process.exit(isValid ? 0 : 1);
}

module.exports = SetupValidator;
