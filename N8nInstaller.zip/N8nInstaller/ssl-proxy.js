const https = require('https');
const http = require('http');
const fs = require('fs');
const forge = require('node-forge');

class SSLProxy {
    constructor() {
        this.httpsPort = 443;
        this.httpPort = 5000;
        this.certPath = './ssl/cert.pem';
        this.keyPath = './ssl/key.pem';
    }

    // Generate self-signed certificate
    generateSelfSignedCert() {
        const keys = forge.pki.rsa.generateKeyPair(2048);
        const cert = forge.pki.createCertificate();
        
        cert.publicKey = keys.publicKey;
        cert.serialNumber = '01';
        cert.validity.notBefore = new Date();
        cert.validity.notAfter = new Date();
        cert.validity.notAfter.setFullYear(cert.validity.notBefore.getFullYear() + 1);
        
        const attrs = [{
            name: 'commonName',
            value: 'localhost'
        }, {
            name: 'countryName',
            value: 'US'
        }, {
            shortName: 'ST',
            value: 'State'
        }, {
            name: 'localityName',
            value: 'City'
        }, {
            name: 'organizationName',
            value: 'n8n'
        }];
        
        cert.setSubject(attrs);
        cert.setIssuer(attrs);
        cert.setExtensions([{
            name: 'basicConstraints',
            cA: true
        }, {
            name: 'keyUsage',
            keyCertSign: true,
            digitalSignature: true,
            nonRepudiation: true,
            keyEncipherment: true,
            dataEncipherment: true
        }, {
            name: 'subjectAltName',
            altNames: [{
                type: 2,
                value: 'localhost'
            }, {
                type: 7,
                ip: '127.0.0.1'
            }]
        }]);
        
        cert.sign(keys.privateKey);
        
        const certPem = forge.pki.certificateToPem(cert);
        const keyPem = forge.pki.privateKeyToPem(keys.privateKey);
        
        // Create ssl directory
        if (!fs.existsSync('./ssl')) {
            fs.mkdirSync('./ssl');
        }
        
        fs.writeFileSync(this.certPath, certPem);
        fs.writeFileSync(this.keyPath, keyPem);
        
        console.log('SSL certificates generated');
    }

    // Create HTTPS proxy
    createProxy() {
        if (!fs.existsSync(this.certPath) || !fs.existsSync(this.keyPath)) {
            this.generateSelfSignedCert();
        }

        const options = {
            key: fs.readFileSync(this.keyPath),
            cert: fs.readFileSync(this.certPath)
        };

        const server = https.createServer(options, (req, res) => {
            const proxyReq = http.request({
                hostname: 'localhost',
                port: this.httpPort,
                path: req.url,
                method: req.method,
                headers: req.headers
            }, (proxyRes) => {
                res.writeHead(proxyRes.statusCode, proxyRes.headers);
                proxyRes.pipe(res);
            });

            proxyReq.on('error', (err) => {
                res.writeHead(502);
                res.end('Bad Gateway');
            });

            req.pipe(proxyReq);
        });

        server.listen(this.httpsPort, () => {
            console.log(`HTTPS proxy running on port ${this.httpsPort}`);
        });
    }
}

module.exports = SSLProxy;