const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

class ServerManager {
    constructor() {
        this.processes = [];
        this.ports = {
            n8n: 5000,
            keepalive: 3000,
            monitor: 8080
        };
    }

    // Wait for port to be available
    waitForPort(port, timeout = 30000) {
        return new Promise((resolve) => {
            const startTime = Date.now();
            const checkPort = () => {
                const req = http.get(`http://localhost:${port}`, (res) => {
                    console.log(`✅ Port ${port} is responding`);
                    resolve(true);
                }).on('error', () => {
                    if (Date.now() - startTime < timeout) {
                        setTimeout(checkPort, 1000);
                    } else {
                        console.log(`⏱️ Timeout waiting for port ${port}`);
                        resolve(false);
                    }
                });
                req.setTimeout(1000, () => req.destroy());
            };
            setTimeout(checkPort, 2000);
        });
    }

    // Start n8n server
    startN8n() {
        return new Promise((resolve) => {
            console.log('🚀 Starting n8n server...');
            const n8nProcess = spawn('node', ['app.js'], {
                stdio: 'pipe',
                env: { ...process.env, NODE_ENV: 'production' }
            });

            n8nProcess.stdout.on('data', (data) => {
                const output = data.toString();
                if (output.includes('Editor is now accessible')) {
                    console.log('✅ n8n server started successfully');
                    resolve(true);
                }
                process.stdout.write(`[n8n] ${output}`);
            });

            n8nProcess.stderr.on('data', (data) => {
                process.stderr.write(`[n8n ERROR] ${data}`);
            });

            n8nProcess.on('close', (code) => {
                console.log(`n8n process exited with code ${code}`);
            });

            this.processes.push(n8nProcess);
            
            // Fallback timeout
            setTimeout(() => resolve(true), 15000);
        });
    }

    // Start keep alive server
    startKeepAlive() {
        return new Promise((resolve) => {
            console.log('🔄 Starting keep alive server...');
            const keepAliveProcess = spawn('node', ['keepalive.js'], {
                stdio: 'pipe',
                env: process.env
            });

            keepAliveProcess.stdout.on('data', (data) => {
                const output = data.toString();
                if (output.includes('Keep Alive server running')) {
                    console.log('✅ Keep alive server started');
                    resolve(true);
                }
                process.stdout.write(`[KeepAlive] ${output}`);
            });

            keepAliveProcess.stderr.on('data', (data) => {
                process.stderr.write(`[KeepAlive ERROR] ${data}`);
            });

            keepAliveProcess.on('close', (code) => {
                console.log(`Keep alive process exited with code ${code}`);
            });

            this.processes.push(keepAliveProcess);
            
            // Fallback timeout
            setTimeout(() => resolve(true), 10000);
        });
    }

    // Start monitor server
    startMonitor() {
        return new Promise((resolve) => {
            console.log('🔍 Starting monitor server...');
            const monitorProcess = spawn('node', ['monitor.js'], {
                stdio: 'pipe',
                env: process.env
            });

            monitorProcess.stdout.on('data', (data) => {
                const output = data.toString();
                if (output.includes('Monitor dashboard running')) {
                    console.log('✅ Monitor server started');
                    resolve(true);
                }
                process.stdout.write(`[Monitor] ${output}`);
            });

            monitorProcess.stderr.on('data', (data) => {
                process.stderr.write(`[Monitor ERROR] ${data}`);
            });

            monitorProcess.on('close', (code) => {
                console.log(`Monitor process exited with code ${code}`);
            });

            this.processes.push(monitorProcess);
            
            // Fallback timeout
            setTimeout(() => resolve(true), 5000);
        });
    }

    // Start all servers in sequence
    async startAll() {
        console.log('🚀 Starting all servers...\n');

        try {
            // Start n8n first (most important)
            await this.startN8n();
            await this.waitForPort(this.ports.n8n);

            // Start keep alive server
            await this.startKeepAlive();
            await this.waitForPort(this.ports.keepalive);

            // Start monitor server
            await this.startMonitor();
            await this.waitForPort(this.ports.monitor);

            this.displayStatus();

        } catch (error) {
            console.error('❌ Error starting servers:', error);
        }
    }

    // Display server status
    displayStatus() {
        console.log('\n' + '='.repeat(50));
        console.log('🎉 ALL SERVERS STARTED SUCCESSFULLY');
        console.log('='.repeat(50));
        console.log(`📊 n8n Interface:      http://localhost:${this.ports.n8n}`);
        console.log(`🔄 Keep Alive Server:  http://localhost:${this.ports.keepalive}`);
        console.log(`🔍 Monitor Dashboard:  http://localhost:${this.ports.monitor}`);
        console.log('='.repeat(50));
        console.log('🛡️ Project is now protected against shutdown');
        console.log('📈 All services are monitored and will auto-restart');
        console.log('⚡ Activity simulation is active every 2 minutes');
        console.log('🏥 Health checks running every 30 seconds');
        console.log('='.repeat(50));
        console.log('\nPress Ctrl+C to stop all servers\n');
    }

    // Handle graceful shutdown
    handleShutdown() {
        console.log('\n🛑 Shutting down all servers...');
        
        this.processes.forEach((process, index) => {
            console.log(`Stopping process ${index + 1}...`);
            process.kill('SIGTERM');
        });

        setTimeout(() => {
            console.log('✅ All servers stopped');
            process.exit(0);
        }, 2000);
    }
}

// Main execution
const manager = new ServerManager();

// Handle graceful shutdown
process.on('SIGINT', () => manager.handleShutdown());
process.on('SIGTERM', () => manager.handleShutdown());

// Start all servers
manager.startAll();

module.exports = ServerManager;