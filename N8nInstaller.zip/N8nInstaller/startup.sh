#!/bin/bash

echo "=== n8n Workflow Automation Setup ==="
echo "Initializing n8n installation..."

# Create necessary directories
mkdir -p workflows
mkdir -p public

# Set proper permissions
chmod +x startup.sh

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "Error: Node.js is not installed. Please install Node.js first."
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "Error: npm is not installed. Please install npm first."
    exit 1
fi

echo "Node.js and npm are available"
echo "Node.js version: $(node --version)"
echo "npm version: $(npm --version)"

# Initialize npm if package.json doesn't exist
if [ ! -f "package.json" ]; then
    echo "Initializing npm project..."
    npm init -y
fi

# Start the n8n setup
echo "Starting n8n setup..."
node app.js

echo "Setup script completed."
